﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class to holde struct of data level has
/// </summary>
public class LevelData : MonoBehaviour
{
    public int totalCans;       //count of cans to detroy
    public int totalBalls;      //total number of Ball we have
}

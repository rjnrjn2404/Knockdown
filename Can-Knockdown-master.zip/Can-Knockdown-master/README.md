# Can_Knockdown
 Complete Can Knockdown Unity Project

## Tutorial
[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/sNRtAJo87G8/0.jpg)](http://www.youtube.com/watch?v=sNRtAJo87G8)

## GamePlay
![Can Knockdown](https://media.giphy.com/media/jslxoPyNqvccIZN1Rp/giphy.gif)

## Credit
* Font:Film Himmel - Jens R. Ziehn / https://www.1001freefonts.com/28-days-later.font
* 3D Art: https://assetstore.unity.com/packages/3d/environments/surroundead-free-sample-76704
* Swipe Control: https://www.youtube.com/watch?v=7O9bAFyGvH8

<div align="left">

### Show some ❤️ and Support!

<a href="https://www.patreon.com/bePatron?u=2787703">
  <img src="https://user-images.githubusercontent.com/39331790/55590317-6c603c80-572a-11e9-8f26-c5976ecf685b.png" width="200" height="47"/>
</a>

<a href="https://www.buymeacoffee.com/Madfireon">
  <img src="https://www.the3rdsequence.com/texturedb/images/donate/buymeacoffee.svg" width="200" height="47"/>
</a>

</div>
